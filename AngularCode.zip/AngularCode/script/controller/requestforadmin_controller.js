'use strict';

MyApp.controller('RequestAdminController', ['$scope', 'AdminService', function($scope, AdminService) {
	
	$scope.register={};
	$scope.requestForAdmin=function(){
		console.log($scope.admin);
		$('#messageDiv').hide();
		AdminService.requestForAdmin($scope.admin)
		.then(function(data){
			console.log(data);
			if(data.status==200){
				$('#messageDiv').show();
				$scope.register.message=data.message;
				$scope.admin={};
			}
		},function(data){
			console.log(data)
			$('#messageDiv').show();
			$scope.register.message="Error occured while requesting."
		});
	}
          
}]);
