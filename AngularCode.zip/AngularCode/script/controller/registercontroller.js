'use strict';

MyApp.controller('AdminRegisterController', ['$scope', 'RegisterService', function($scope, RegisterService) {
	
	$scope.loadDefault=function(){
		$scope.admin={};
		$scope.loggedInUser = $.jStorage.get("user");
		$scope.token = $.jStorage.get("token");
		console.log($scope.loggedInUser, $scope.token);
		$scope.admin.email=$scope.loggedInUser.email;
		$scope.admin.id=$scope.loggedInUser.id
	}
	$scope.registerforAdmin=function(){
		console.log($scope.admin);
		
		if($scope.loggedInUser==null && $scope.token == null){
			
		}
		else{
			
			var admin={
					id:$scope.admin.id || null,
					firstName:$scope.admin.firstName || null,
					middleName:$scope.admin.middleName || null,
					lastName:$scope.admin.lastName || null,
					email:$scope.loggedInUser.email || null,
					password:$scope.admin.password || null,
					country:$scope.admin.country || null,
					state:$scope.admin.state || null,
					city:$scope.admin.city || null,
					pin:$scope.admin.pin || null,
					mobile:$scope.admin.mobile || null,
					organisationName:$scope.admin.organisationName || null,
					regdNo:$scope.admin.regdNo || null,
					orgPhone:$scope.admin.orgPhone || null,
					orgAddress:$scope.admin.orgAddress || null,
					license:{
							licenseType:$('#licenseType').val() || null,
							licensePeriod:$('#licensePeriod').val() || null,
						 }
			}
			console.log(admin);
			RegisterService.registerforAdmin(admin, $scope.loggedInUser , $scope.token)
			.then(function(data){
				if(data.status==200){
					
				}
			},function(data){
				console.log(data)
			});
		}
	}
          
}]);
