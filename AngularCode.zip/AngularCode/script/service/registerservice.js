'use strict';
MyApp.factory('RegisterService', ['$http', '$q', function($http, $q){

var RegisterService={
		registerforAdmin:registerforAdmin	
	}
	return RegisterService;
	
	function registerforAdmin(admin, loginuser, token){
		var defer = $q.defer();
		var config={
				headers:{
				"Authorization":"Bearer "+ token.access_token,
				"Accept" : "application/json",
				"Content-Type" : "application/json"
				}
		}
		var data=admin;
		$http.post('http://localhost:8082/api/registeradmin?loginuser='+loginuser, data, config)
		.success(function(response) {
			defer.resolve(response);
		})
		.error(function(err) {
			defer.reject(err);
		}); 
			
		return defer.promise;
	}
	
		

}]);
