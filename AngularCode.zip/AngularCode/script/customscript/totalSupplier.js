var encryptedUserName="";
var userType;
var reuseprojectName;
var reuseSummary;
var reuseContactPersonName;
var reuseAutomationName;
var reuseExcelDownloadId;
var reusedownloadCount;
var reusedownloadCountval;
var reuseContributorName;
var responseDataReuse;
$(document).ready(function () {
	responseDataReuse=[
		{
			"serialNum": 1,
			"supplierName": "Jatin Sharma",
			"businessName": "Svadha wash Pvt Ltd",
			"email": "anantaprasad.ojha@gmail.com",
			"phone": "7751996235",
			"state": "Odisha",
			"city": "Bhubaneswar",
			"pin": "751013",
			"status": "Active",
		},
		

		];



	reuseArrayHeader = [
		{ "sTitle": "S.No", "mData": "serialNum" },
		{ "sTitle": "Supplier Name", "mData": "supplierName" },
		{ "sTitle": "Business Name", "mData": "businessName" },
		{ "sTitle": "Email", "mData": "email" },
		{ "sTitle": "Phone", "mData": "phone" },
		{ "sTitle": "State", "mData": "state" },
		{ "sTitle": "City", "mData": "city" },
		{ "sTitle": "Pin", "mData": "pin" },
		{ "sTitle": "Status", "mData": "status" }

		]

			showReuseTableData();


});


function showReuseTableData(){

	showReuseTable(responseDataReuse);


}


function showReuseTable(jsonData){
	$('#tableId').addClass( 'nowrap' ).dataTable({
		"aaData": jsonData,
		dom: 'lBfrtip',
		"bFilter" : true, 
		"bPaginate": true,
		"lengthMenu": [5,10,15,20],
		buttons: ['excel' , 'print','copyHtml5'],
		// "scrollY": 200,
		fixedHeader: true,

		"scrollX": true,
		"aoColumns":reuseArrayHeader

	}); 
} 


