
var reuseArrayHeader;
var responseDataReuse;

$(document).ready(function () {

	responseDataReuse=[
		  {
			    "slno": 1,
			    "first_name": "Jessica",
			    "email_id": "",
			    "shop_lic_expiry_date": "02-06-2018",
			    "Mobile": 7064428282
			  },
			  {
			    "slno": 2,
			    "first_name": "Jessica",
			    "email_id": "",
			    "shop_lic_expiry_date": "02-06-2018",
			    "Mobile": 7064428282
			  },
			  {
			    "slno": 3,
			    "first_name": "jrss",
			    "email_id": "",
			    "shop_lic_expiry_date": "02-06-2020",
			    "Mobile": 7327079122
			  },
			  {
			    "slno": 4,
			    "first_name": "test",
			    "email_id": "",
			    "shop_lic_expiry_date": "04-06-2017",
			    "Mobile": 8892234780
			  },
			  {
			    "slno": 5,
			    "first_name": "suhasini",
			    "email_id": "",
			    "shop_lic_expiry_date": "08-06-2017",
			    "Mobile": 7008348432
			  },
			  {
			    "slno": 6,
			    "first_name": "Testtest",
			    "email_id": "",
			    "shop_lic_expiry_date": "08-06-2017",
			    "Mobile": 9439977941
			  },
			  {
			    "slno": 7,
			    "first_name": "rohan",
			    "email_id": "",
			    "shop_lic_expiry_date": "17-06-2017",
			    "Mobile": 7325916608
			  },
			  {
			    "slno": 8,
			    "first_name": "Testa",
			    "email_id": "",
			    "shop_lic_expiry_date": "14-07-2017",
			    "Mobile": 7326089575
			  },
			  {
			    "slno": 9,
			    "first_name": "Chetana",
			    "email_id": "",
			    "shop_lic_expiry_date": "29-09-2017",
			    "Mobile": 9861191075
			  },
			  {
			    "slno": 10,
			    "first_name": "bimal",
			    "email_id": "",
			    "shop_lic_expiry_date": "30-06-2017",
			    "Mobile": 8249693512
			  },
			  {
			    "slno": 11,
			    "first_name": "Suchisnata",
			    "email_id": "",
			    "shop_lic_expiry_date": "16-06-2017",
			    "Mobile": 7894459696
			  },
			  {
			    "slno": 12,
			    "first_name": "bimal",
			    "email_id": "",
			    "shop_lic_expiry_date": "30-06-2017",
			    "Mobile": 7978116181
			  },
			  {
			    "slno": 13,
			    "first_name": "Yash",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": "NULL"
			  },
			  {
			    "slno": 14,
			    "first_name": "bimaltest",
			    "email_id": "",
			    "shop_lic_expiry_date": "31-07-2017",
			    "Mobile": 8280166021
			  },
			  {
			    "slno": 15,
			    "first_name": "Ritesh",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7752009852
			  },
			  {
			    "slno": 16,
			    "first_name": "glp",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9573792244
			  },
			  {
			    "slno": 17,
			    "first_name": "Samir",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 8114374024
			  },
			  {
			    "slno": 18,
			    "first_name": "testranajoy",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 8260136888
			  },
			  {
			    "slno": 19,
			    "first_name": "chidatesteki",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9439554283
			  },
			  {
			    "slno": 20,
			    "first_name": "asirbad",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9658859571
			  },
			  {
			    "slno": 21,
			    "first_name": "Yash",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9998761760
			  },
			  {
			    "slno": 22,
			    "first_name": "Svadha",
			    "email_id": "",
			    "shop_lic_expiry_date": "27-07-2017",
			    "Mobile": 8249709205
			  },
			  {
			    "slno": 23,
			    "first_name": "Suhasini",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9778293557
			  },
			  {
			    "slno": 24,
			    "first_name": "sananda",
			    "email_id": "",
			    "shop_lic_expiry_date": "31-08-2017",
			    "Mobile": 9036034341
			  },
			  {
			    "slno": 25,
			    "first_name": "Sanand",
			    "email_id": "",
			    "shop_lic_expiry_date": "31-08-2017",
			    "Mobile": 8114334223
			  },
			  {
			    "slno": 26,
			    "first_name": "Yash",
			    "email_id": "",
			    "shop_lic_expiry_date": "07-08-2035",
			    "Mobile": 8114366211
			  },
			  {
			    "slno": 27,
			    "first_name": "Amulya",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9556175561
			  },
			  {
			    "slno": 28,
			    "first_name": "Shamia",
			    "email_id": "",
			    "shop_lic_expiry_date": "06-08-2017",
			    "Mobile": 8895730661
			  },
			  {
			    "slno": 29,
			    "first_name": "Sanand",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9861613261
			  },
			  {
			    "slno": 30,
			    "first_name": "banamali",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9861326133
			  },
			  {
			    "slno": 31,
			    "first_name": "Pulak",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7752009859
			  },
			  {
			    "slno": 32,
			    "first_name": "testing",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9776997309
			  },
			  {
			    "slno": 33,
			    "first_name": "Sanand",
			    "email_id": "",
			    "shop_lic_expiry_date": "20-08-2017",
			    "Mobile": 7978307168
			  },
			  {
			    "slno": 34,
			    "first_name": "bimal",
			    "email_id": "",
			    "shop_lic_expiry_date": "31-08-2017",
			    "Mobile": 9124290931
			  },
			  {
			    "slno": 35,
			    "first_name": "dp",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7978552718
			  },
			  {
			    "slno": 36,
			    "first_name": "ASHOK",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9861755735
			  },
			  {
			    "slno": 37,
			    "first_name": "satyaban",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9668725721
			  },
			  {
			    "slno": 38,
			    "first_name": "Ekistics",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9840199175
			  },
			  {
			    "slno": 39,
			    "first_name": "bighna",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9776995223
			  },
			  {
			    "slno": 40,
			    "first_name": "dusmanta",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9439926781
			  },
			  {
			    "slno": 41,
			    "first_name": "Ambuja",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9338327270
			  },
			  {
			    "slno": 42,
			    "first_name": "Prashant",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9668422926
			  },
			  {
			    "slno": 43,
			    "first_name": "Satya",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 8908066877
			  },
			  {
			    "slno": 44,
			    "first_name": "Manoj",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9937797748
			  },
			  {
			    "slno": 45,
			    "first_name": "Asish",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7894814100
			  },
			  {
			    "slno": 46,
			    "first_name": "Sanjaya",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7377060048
			  },
			  {
			    "slno": 47,
			    "first_name": "Ranjan",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9439808003
			  },
			  {
			    "slno": 48,
			    "first_name": "SARADA",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9853733641
			  },
			  {
			    "slno": 49,
			    "first_name": "Rama",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9437468431
			  },
			  {
			    "slno": 50,
			    "first_name": "jateswar",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7064428281
			  },
			  {
			    "slno": 51,
			    "first_name": "Anil",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 8917351300
			  },
			  {
			    "slno": 52,
			    "first_name": "babula",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9040204166
			  },
			  {
			    "slno": 53,
			    "first_name": "Muktikanta",
			    "email_id": "",
			    "shop_lic_expiry_date": "08-11-2020",
			    "Mobile": 9861685914
			  },
			  {
			    "slno": 54,
			    "first_name": "sunil",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7894272902
			  },
			  {
			    "slno": 55,
			    "first_name": "SASHIKANTA",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9178153184
			  },
			  {
			    "slno": 56,
			    "first_name": "PRAFULLA",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9937880685
			  },
			  {
			    "slno": 57,
			    "first_name": "Samir",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9438304553
			  },
			  {
			    "slno": 58,
			    "first_name": "nitish",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 8826550746
			  },
			  {
			    "slno": 59,
			    "first_name": "Gajendranath",
			    "email_id": "",
			    "shop_lic_expiry_date": "19-11-2017",
			    "Mobile": 9040400731
			  },
			  {
			    "slno": 60,
			    "first_name": "ranjan",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9668476558
			  },
			  {
			    "slno": 61,
			    "first_name": "Susant",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9937074485
			  },
			  {
			    "slno": 62,
			    "first_name": "Manoranjan",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9777684447
			  },
			  {
			    "slno": 63,
			    "first_name": "prasanta",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9668221282
			  },
			  {
			    "slno": 64,
			    "first_name": "DILIP",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9437927114
			  },
			  {
			    "slno": 65,
			    "first_name": "Ranjan",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9937460361
			  },
			  {
			    "slno": 66,
			    "first_name": "Ashok",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7978529719
			  },
			  {
			    "slno": 67,
			    "first_name": "SUBHRANSU",
			    "email_id": "",
			    "shop_lic_expiry_date": "24-11-2018",
			    "Mobile": 8249112795
			  },
			  {
			    "slno": 68,
			    "first_name": "dipti",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9040456697
			  },
			  {
			    "slno": 69,
			    "first_name": "braja",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7809378890
			  },
			  {
			    "slno": 70,
			    "first_name": "MANORANJAN",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9938152395
			  },
			  {
			    "slno": 71,
			    "first_name": "Bibhu",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9437532272
			  },
			  {
			    "slno": 72,
			    "first_name": "NALINI",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9937139898
			  },
			  {
			    "slno": 73,
			    "first_name": "MADHABANANDA",
			    "email_id": "",
			    "shop_lic_expiry_date": "25-11-2018",
			    "Mobile": 9861009341
			  },
			  {
			    "slno": 74,
			    "first_name": "Jatin",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7751996235
			  },
			  {
			    "slno": 75,
			    "first_name": "Ranjan",
			    "email_id": "",
			    "shop_lic_expiry_date": "28-11-2017",
			    "Mobile": 7873835335
			  },
			  {
			    "slno": 76,
			    "first_name": "SURENDRA",
			    "email_id": "",
			    "shop_lic_expiry_date": "29-11-2018",
			    "Mobile": 7873947803
			  },
			  {
			    "slno": 77,
			    "first_name": "BIKASH",
			    "email_id": "",
			    "shop_lic_expiry_date": "30-11-2018",
			    "Mobile": 9658358124
			  },
			  {
			    "slno": 78,
			    "first_name": "BISWOJIT",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7205567482
			  },
			  {
			    "slno": 79,
			    "first_name": "MANIKANTA",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9040701147
			  },
			  {
			    "slno": 80,
			    "first_name": "PRAMOD",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 8093698793
			  },
			  {
			    "slno": 81,
			    "first_name": "BIBHU",
			    "email_id": "",
			    "shop_lic_expiry_date": "02-12-2017",
			    "Mobile": 9437267284
			  },
			  {
			    "slno": 82,
			    "first_name": "Atanu",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9937899021
			  },
			  {
			    "slno": 83,
			    "first_name": "PURNA",
			    "email_id": "",
			    "shop_lic_expiry_date": "08-12-2018",
			    "Mobile": 7978870857
			  },
			  {
			    "slno": 84,
			    "first_name": "RASMI",
			    "email_id": "",
			    "shop_lic_expiry_date": "08-12-2018",
			    "Mobile": 9861145886
			  },
			  {
			    "slno": 85,
			    "first_name": "Sanand",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 8280166021
			  },
			  {
			    "slno": 86,
			    "first_name": "babuliraut",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 8342002559
			  },
			  {
			    "slno": 87,
			    "first_name": "samir",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9438304553
			  },
			  {
			    "slno": 88,
			    "first_name": "Sananda",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9036034341
			  },
			  {
			    "slno": 89,
			    "first_name": "Jateswar",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7064428281
			  },
			  {
			    "slno": 90,
			    "first_name": "Rashmi",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9853111787
			  },
			  {
			    "slno": 91,
			    "first_name": "CHINMAYA",
			    "email_id": "",
			    "shop_lic_expiry_date": "16-12-2018",
			    "Mobile": 9938149733
			  },
			  {
			    "slno": 92,
			    "first_name": "Sananda",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9337399618
			  },
			  {
			    "slno": 93,
			    "first_name": "Debi",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9090208848
			  },
			  {
			    "slno": 94,
			    "first_name": "Balakrishna",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9439908209
			  },
			  {
			    "slno": 95,
			    "first_name": "Dillip",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9437742929
			  },
			  {
			    "slno": 96,
			    "first_name": "SARADA",
			    "email_id": "",
			    "shop_lic_expiry_date": "20-12-2017",
			    "Mobile": 7328824287
			  },
			  {
			    "slno": 97,
			    "first_name": "shantanu",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9556855889
			  },
			  {
			    "slno": 98,
			    "first_name": "sailabala",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7752009856
			  },
			  {
			    "slno": 99,
			    "first_name": "Dhirendra",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9437918301
			  },
			  {
			    "slno": 100,
			    "first_name": "Madhu",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 8383813612
			  },
			  {
			    "slno": 101,
			    "first_name": "jayashree",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 8114366633
			  },
			  {
			    "slno": 102,
			    "first_name": "Samir",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7008956784
			  },
			  {
			    "slno": 103,
			    "first_name": "Sanjay",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9937658598
			  },
			  {
			    "slno": 104,
			    "first_name": "CHANDRA",
			    "email_id": "",
			    "shop_lic_expiry_date": "22-12-2017",
			    "Mobile": 9937760072
			  },
			  {
			    "slno": 105,
			    "first_name": "Niky",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9853290857
			  },
			  {
			    "slno": 106,
			    "first_name": "kunja",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9439614669
			  },
			  {
			    "slno": 107,
			    "first_name": "KSHIRASINDHU",
			    "email_id": "",
			    "shop_lic_expiry_date": "22-12-2018",
			    "Mobile": 9668608536
			  },
			  {
			    "slno": 108,
			    "first_name": "SRIKANTA",
			    "email_id": "",
			    "shop_lic_expiry_date": "23-12-2018",
			    "Mobile": 8249112795
			  },
			  {
			    "slno": 109,
			    "first_name": "manas",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 8456890025
			  },
			  {
			    "slno": 110,
			    "first_name": "Ananta",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 8908011908
			  },
			  {
			    "slno": 111,
			    "first_name": "Susil",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9437423392
			  },
			  {
			    "slno": 112,
			    "first_name": "Ranjeet",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9238842541
			  },
			  {
			    "slno": 113,
			    "first_name": "Pravat",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 8260592093
			  },
			  {
			    "slno": 114,
			    "first_name": "Ritesh",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7752009852
			  },
			  {
			    "slno": 115,
			    "first_name": "nikhil",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9853290857
			  },
			  {
			    "slno": 116,
			    "first_name": "sujit",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7788993696
			  },
			  {
			    "slno": 117,
			    "first_name": "BATA",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9178322615
			  },
			  {
			    "slno": 118,
			    "first_name": "chittaranjan",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9776231317
			  },
			  {
			    "slno": 119,
			    "first_name": "Dillip",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 8917226535
			  },
			  {
			    "slno": 120,
			    "first_name": "SOUMYA",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7377564002
			  },
			  {
			    "slno": 121,
			    "first_name": "Abhijeet",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9040066454
			  },
			  {
			    "slno": 122,
			    "first_name": "Biswamitra",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 8328844247
			  },
			  {
			    "slno": 123,
			    "first_name": "JYOTIRMAYA",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9439865221
			  },
			  {
			    "slno": 124,
			    "first_name": "Basanta",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9437652674
			  },
			  {
			    "slno": 125,
			    "first_name": "RAMNARAYAN",
			    "email_id": "",
			    "shop_lic_expiry_date": "21-01-2018",
			    "Mobile": 8658268345
			  },
			  {
			    "slno": 126,
			    "first_name": "bipin",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7504915821
			  },
			  {
			    "slno": 127,
			    "first_name": "SAROJ",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9337116949
			  },
			  {
			    "slno": 128,
			    "first_name": "Rajkishor",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9937593217
			  },
			  {
			    "slno": 129,
			    "first_name": "Prakash",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 8984467655
			  },
			  {
			    "slno": 130,
			    "first_name": "sahafaiz",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9090091909
			  },
			  {
			    "slno": 131,
			    "first_name": "Amit",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 7504193014
			  },
			  {
			    "slno": 132,
			    "first_name": "jayprakash",
			    "email_id": "",
			    "shop_lic_expiry_date": "NULL",
			    "Mobile": 9437301244
			  }
			];
	
	
	reuseArrayHeader = [
		{ "sTitle": "S.No", "mData": "slno" },
		{ "sTitle": "Name", "mData": "first_name" },
		{ "sTitle": "EmailId", "mData": "email_id" },
		{ "sTitle": "Date", "mData": "shop_lic_expiry_date" },
		{ "sTitle": "Mobile", "mData": "Mobile" }
		]
	
	showReuseTableData(responseDataReuse);
});

function showReuseTableData(responseDataReuse){

	
	
	$('#totalentreprenure').addClass( 'nowrap' ).dataTable({
		"aaData": responseDataReuse,
		dom: 'lBfrtip',
		"bFilter" : true, 
		"bPaginate": true,
		"lengthMenu": [5,10,15,20],
		buttons: ['excel' , 'print','copyHtml5'],
		// "scrollY": 200,
		fixedHeader: true,

		"scrollX": true,
		"aoColumns":reuseArrayHeader

	}); 
} 





