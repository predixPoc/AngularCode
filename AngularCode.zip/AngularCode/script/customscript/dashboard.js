
var baseurl;
var totalData;
var wholeTransaction;
$(document).ready(function () {
 
  baseurl="http://localhost:8082/api/totalnofordashboard";
    $.ajax({
        url:baseurl,
       type: "GET", //send it through GET method
       success: function(responseData) {
          console.log(responseData);
         
          $("#totalsupplier").html(responseData.object.totalSupplier);
          $("#totalproduct").html(responseData.object.totalProduct);
          $("#totalitem").html(responseData.object.totaliTEM);
          $("#totalorder").html(responseData.object.totalOrder);
          wholeTransaction =  formatNumber(responseData.object.totalTransaction);
          $("#totaltransaction").html(wholeTransaction);
	     },
        error: function (xhr, status, error) {
		  console.log("Error while fetching Automation tracker data.");
       }
   });
	
	
    
    totalData="http://localhost:8082/api/topproductorder";
    var toponeproduct;
    var toptwoproduct;
    var topthreeproduct;
    var topfourproduct;
    var topfiveproduct;
    var toponequantity;
    var toptwoquantity;
    var topthreequantity;
    var topfourquantity;
    var topfivequantity;
    $.ajax({
        url:totalData,
       type: "GET", //send it through GET method
       success: function(responseData) {
          console.log(responseData);
        
          for(var i=0;i<responseData.object.length;i++){
        	  if(i==0){
        		  toponeproduct=responseData.object[i].productName;
        		  $("#topone").html(toponeproduct);
        		  toponequantity=responseData.object[i].totalorder;
        	  }
        	  if(i==1){
        		  toptwoproduct=responseData.object[i].productName;
        		  $("#toptwo").html(toptwoproduct);
        		  toptwoquantity=responseData.object[i].totalorder;
        	  }
        	  if(i==2){
        		  topthreeproduct=responseData.object[i].productName;
        		  $("#topthree").html(topthreeproduct);
        		  topthreequantity=responseData.object[i].totalorder;
        	  }
        	  if(i==3){
        		  topfourproduct=responseData.object[i].productName;
        		  $("#topfour").html(topfourproduct);
        		  topfourquantity=responseData.object[i].totalorder;
        	  }
        	  if(i==4){
        		  topfiveproduct=responseData.object[i].productName;
        		  $("#topfive").html(topfiveproduct);
        		  topfivequantity=responseData.object[i].totalorder;
        	  }
          }
     
	     },
        error: function (xhr, status, error) {
		  console.log("Error while fetching Automation tracker data.");
       }
   });

});



function formatNumber(num){
    return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,")
}
